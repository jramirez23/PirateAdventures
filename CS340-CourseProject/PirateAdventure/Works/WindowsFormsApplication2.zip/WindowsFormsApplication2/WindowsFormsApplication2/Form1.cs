﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace AsianOptionsConsole
{
    public partial class Form1 : Form
    {
        AOSPricing Pricing = new AOSPricing();
        long tempL;
        double tempD;
        string paramaters;
        string priceS;
        Thread thr;
        string s = "";

        public Form1()
        {
                InitializeComponent();
        }        

        private async void analyzeButton_Click(object sender, EventArgs e)
        {
            string simulations = await Task.Run(() => Pricing.getSimulations());
            resultsBox.AppendText(simulations);
        }

        private void initialButton_Click(object sender, EventArgs e)
        {
            if (double.TryParse(initialBox.Text, out tempD))  // parse successful:
            {
                // make sure value is reasonable, and if so, update sims to input value:
                if (tempD > 0)
                {
                    Pricing.initial = tempD;
                }
            }
        }

        private void interestButton_Click(object sender, EventArgs e)
        {
            if (double.TryParse(interestBox.Text, out tempD))  // parse successful:
            {
                // make sure value is reasonable, and if so, update sims to input value:
                if (tempD > 0 && tempD <= 100)
                {
                    Pricing.interest = tempD;
                }
            }
        }

        private void simulationsButton_Click(object sender, EventArgs e)
        {
            if (long.TryParse(simulationsBox.Text, out tempL))  // parse successful:
            {
                // make sure value is reasonable, and if so, update sims to input value:
                if (tempL > 0)
                {
                    Pricing.sims = tempL;
                }
            }
        }

        private void exerciseButton_Click(object sender, EventArgs e)
        {
            if (double.TryParse(exerciseBox.Text, out tempD))  // parse successful:
            {
                // make sure value is reasonable, and if so, update sims to input value:
                if (tempD > 0)
                {
                    Pricing.exercise = tempD;
                }
            }
        }

        private void upperButton_Click(object sender, EventArgs e)
        {
            if (double.TryParse(interestBox.Text, out tempD))  // parse successful:
            {
                // make sure value is reasonable, and if so, update sims to input value:
                if (tempD > 0)
                {
                    Pricing.up = tempD;
                }
            }
        }

        private void lowerButton_Click(object sender, EventArgs e)
        {
            if (double.TryParse(interestBox.Text, out tempD))  // parse successful:
            {
                // make sure value is reasonable, and if so, update sims to input value:
                if (tempD > 0)
                {
                    Pricing.down = tempD;
                }
            }
        }

        private void paramatersButton_Click(object sender, EventArgs e)
        {

            string paramaters = "Checking Paramaters for Trial #" + Pricing.index.ToString()
                        + Environment.NewLine + "Initial Price:\t" + String.Format("{0:0.00}", Pricing.initial) 
                        + Environment.NewLine + "Exercise Price: \t" + String.Format("{0:0.00}", Pricing.exercise)
                        + Environment.NewLine + "Upper Bound: \t" + String.Format("{0:0.00}", Pricing.up)
                        + Environment.NewLine + "Lower Bound: \t" + String.Format("{0:0.00}", Pricing.down)
                        + Environment.NewLine + "Interest Rate: \t" + String.Format("{0:0.00}", Pricing.interest)
                        + Environment.NewLine + "Time Period: \t" + Pricing.periods.ToString()
                        + Environment.NewLine + "Simulation Runs: \t" + Pricing.sims.ToString()
                        + Environment.NewLine;
            paramaterBox.AppendText(paramaters);
        }
     }
}
