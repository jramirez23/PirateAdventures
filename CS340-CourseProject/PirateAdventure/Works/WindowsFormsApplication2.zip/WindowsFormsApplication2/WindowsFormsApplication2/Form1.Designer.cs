﻿namespace AsianOptionsConsole
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.analyzeButton = new System.Windows.Forms.Button();
            this.lowerBox = new System.Windows.Forms.TextBox();
            this.paramaterBox = new System.Windows.Forms.TextBox();
            this.resultsBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.simulationsButton = new System.Windows.Forms.Button();
            this.interestButton = new System.Windows.Forms.Button();
            this.upperBox = new System.Windows.Forms.TextBox();
            this.initialButton = new System.Windows.Forms.Button();
            this.exerciseBox = new System.Windows.Forms.TextBox();
            this.upperButton = new System.Windows.Forms.Button();
            this.interestBox = new System.Windows.Forms.TextBox();
            this.lowerButton = new System.Windows.Forms.Button();
            this.simulationsBox = new System.Windows.Forms.TextBox();
            this.exerciseButton = new System.Windows.Forms.Button();
            this.initialBox = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.paramatersButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // analyzeButton
            // 
            this.analyzeButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.analyzeButton.Image = ((System.Drawing.Image)(resources.GetObject("analyzeButton.Image")));
            this.analyzeButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.analyzeButton.Location = new System.Drawing.Point(222, 272);
            this.analyzeButton.Name = "analyzeButton";
            this.analyzeButton.Size = new System.Drawing.Size(185, 23);
            this.analyzeButton.TabIndex = 0;
            this.analyzeButton.Text = "Analyze";
            this.analyzeButton.UseCompatibleTextRendering = true;
            this.analyzeButton.UseVisualStyleBackColor = false;
            this.analyzeButton.Click += new System.EventHandler(this.analyzeButton_Click);
            // 
            // lowerBox
            // 
            this.lowerBox.Location = new System.Drawing.Point(12, 243);
            this.lowerBox.Name = "lowerBox";
            this.lowerBox.Size = new System.Drawing.Size(196, 20);
            this.lowerBox.TabIndex = 1;
            // 
            // paramaterBox
            // 
            this.paramaterBox.Location = new System.Drawing.Point(12, 313);
            this.paramaterBox.Multiline = true;
            this.paramaterBox.Name = "paramaterBox";
            this.paramaterBox.ReadOnly = true;
            this.paramaterBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.paramaterBox.Size = new System.Drawing.Size(196, 133);
            this.paramaterBox.TabIndex = 3;
            // 
            // resultsBox
            // 
            this.resultsBox.Location = new System.Drawing.Point(222, 313);
            this.resultsBox.Multiline = true;
            this.resultsBox.Name = "resultsBox";
            this.resultsBox.ReadOnly = true;
            this.resultsBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.resultsBox.Size = new System.Drawing.Size(185, 133);
            this.resultsBox.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 298);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Paramaters of";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(219, 298);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Results of";
            // 
            // simulationsButton
            // 
            this.simulationsButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.simulationsButton.Location = new System.Drawing.Point(222, 129);
            this.simulationsButton.Name = "simulationsButton";
            this.simulationsButton.Size = new System.Drawing.Size(185, 19);
            this.simulationsButton.TabIndex = 7;
            this.simulationsButton.Text = "Adjust Simulaitions";
            this.simulationsButton.UseVisualStyleBackColor = false;
            this.simulationsButton.Click += new System.EventHandler(this.simulationsButton_Click);
            // 
            // interestButton
            // 
            this.interestButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.interestButton.Location = new System.Drawing.Point(222, 100);
            this.interestButton.Name = "interestButton";
            this.interestButton.Size = new System.Drawing.Size(185, 19);
            this.interestButton.TabIndex = 9;
            this.interestButton.Text = "Adjust Interest";
            this.interestButton.UseVisualStyleBackColor = false;
            this.interestButton.Click += new System.EventHandler(this.interestButton_Click);
            // 
            // upperBox
            // 
            this.upperBox.Location = new System.Drawing.Point(12, 215);
            this.upperBox.Name = "upperBox";
            this.upperBox.Size = new System.Drawing.Size(196, 20);
            this.upperBox.TabIndex = 8;
            // 
            // initialButton
            // 
            this.initialButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.initialButton.Location = new System.Drawing.Point(222, 157);
            this.initialButton.Name = "initialButton";
            this.initialButton.Size = new System.Drawing.Size(185, 20);
            this.initialButton.TabIndex = 11;
            this.initialButton.Text = "Adjust Initial Price";
            this.initialButton.UseVisualStyleBackColor = false;
            this.initialButton.Click += new System.EventHandler(this.initialButton_Click);
            // 
            // exerciseBox
            // 
            this.exerciseBox.Location = new System.Drawing.Point(12, 186);
            this.exerciseBox.Name = "exerciseBox";
            this.exerciseBox.Size = new System.Drawing.Size(196, 20);
            this.exerciseBox.TabIndex = 10;
            // 
            // upperButton
            // 
            this.upperButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.upperButton.Location = new System.Drawing.Point(222, 214);
            this.upperButton.Name = "upperButton";
            this.upperButton.Size = new System.Drawing.Size(185, 20);
            this.upperButton.TabIndex = 17;
            this.upperButton.Text = "Adjust Upper Bound";
            this.upperButton.UseVisualStyleBackColor = false;
            this.upperButton.Click += new System.EventHandler(this.upperButton_Click);
            // 
            // interestBox
            // 
            this.interestBox.Location = new System.Drawing.Point(12, 99);
            this.interestBox.Name = "interestBox";
            this.interestBox.Size = new System.Drawing.Size(196, 20);
            this.interestBox.TabIndex = 16;
            // 
            // lowerButton
            // 
            this.lowerButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lowerButton.Location = new System.Drawing.Point(222, 243);
            this.lowerButton.Name = "lowerButton";
            this.lowerButton.Size = new System.Drawing.Size(185, 20);
            this.lowerButton.TabIndex = 15;
            this.lowerButton.Text = "Adjust Lower Bound";
            this.lowerButton.UseVisualStyleBackColor = false;
            this.lowerButton.Click += new System.EventHandler(this.lowerButton_Click);
            // 
            // simulationsBox
            // 
            this.simulationsBox.Location = new System.Drawing.Point(12, 128);
            this.simulationsBox.Name = "simulationsBox";
            this.simulationsBox.Size = new System.Drawing.Size(196, 20);
            this.simulationsBox.TabIndex = 14;
            // 
            // exerciseButton
            // 
            this.exerciseButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.exerciseButton.Location = new System.Drawing.Point(222, 186);
            this.exerciseButton.Name = "exerciseButton";
            this.exerciseButton.Size = new System.Drawing.Size(185, 20);
            this.exerciseButton.TabIndex = 13;
            this.exerciseButton.Text = "Adjust Exercise Price";
            this.exerciseButton.UseVisualStyleBackColor = false;
            this.exerciseButton.Click += new System.EventHandler(this.exerciseButton_Click);
            // 
            // initialBox
            // 
            this.initialBox.Location = new System.Drawing.Point(12, 157);
            this.initialBox.Name = "initialBox";
            this.initialBox.Size = new System.Drawing.Size(196, 20);
            this.initialBox.TabIndex = 12;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(12, 13);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(395, 80);
            this.textBox9.TabIndex = 18;
            this.textBox9.Text = resources.GetString("textBox9.Text");
            // 
            // paramatersButton
            // 
            this.paramatersButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.paramatersButton.Image = ((System.Drawing.Image)(resources.GetObject("paramatersButton.Image")));
            this.paramatersButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.paramatersButton.Location = new System.Drawing.Point(12, 272);
            this.paramatersButton.Name = "paramatersButton";
            this.paramatersButton.Size = new System.Drawing.Size(196, 23);
            this.paramatersButton.TabIndex = 19;
            this.paramatersButton.Text = "Check Current Paramaters";
            this.paramatersButton.UseVisualStyleBackColor = false;
            this.paramatersButton.Click += new System.EventHandler(this.paramatersButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(419, 458);
            this.Controls.Add(this.paramatersButton);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.upperButton);
            this.Controls.Add(this.interestBox);
            this.Controls.Add(this.lowerButton);
            this.Controls.Add(this.simulationsBox);
            this.Controls.Add(this.exerciseButton);
            this.Controls.Add(this.initialBox);
            this.Controls.Add(this.initialButton);
            this.Controls.Add(this.exerciseBox);
            this.Controls.Add(this.interestButton);
            this.Controls.Add(this.upperBox);
            this.Controls.Add(this.simulationsButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.resultsBox);
            this.Controls.Add(this.paramaterBox);
            this.Controls.Add(this.lowerBox);
            this.Controls.Add(this.analyzeButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Asian Options Console";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button analyzeButton;
        private System.Windows.Forms.TextBox lowerBox;
        private System.Windows.Forms.TextBox paramaterBox;
        private System.Windows.Forms.TextBox resultsBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button simulationsButton;
        private System.Windows.Forms.Button interestButton;
        private System.Windows.Forms.TextBox upperBox;
        private System.Windows.Forms.Button initialButton;
        private System.Windows.Forms.TextBox exerciseBox;
        private System.Windows.Forms.Button upperButton;
        private System.Windows.Forms.TextBox interestBox;
        private System.Windows.Forms.Button lowerButton;
        private System.Windows.Forms.TextBox simulationsBox;
        private System.Windows.Forms.Button exerciseButton;
        private System.Windows.Forms.TextBox initialBox;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Button paramatersButton;
    }
}

