﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsianOptionsConsole
{
    class AOSPricing
    {
        public double initial;
        public double exercise;
        public double up;
        public double down;
        public double interest;
        public long periods;
        public long sims;
        public long temp;
        public int index;

        public AOSPricing()
        {
            initial = 30.0;
            exercise = 30.0;
            up = 1.4;
            down = 0.8;
            interest = 1.08;
            periods = 30;
            sims = 5000000;
            index = 1;
        }
        public async Task<string> getSimulations()
        {
            string ind = index.ToString();
            ++index;
            int start = System.Environment.TickCount;
            double price = AsianOptionsPricing.Simulation(initial, exercise, up, down, interest, periods, sims);
            int stop = System.Environment.TickCount;
            double elapsedTimeInSecs = (stop - start) / 1000.0;
            string simulate = "Simulation #\t" + ind +
                        Environment.NewLine + "Price: \t\t" + String.Format("{0:0.00}", price) +
                        Environment.NewLine + "Time: \t\t" + String.Format("{0:0.00}", elapsedTimeInSecs)
                        + Environment.NewLine + Environment.NewLine;
            return simulate;
        }
    }
}
